
from __future__ import annotations
import os
from pathlib import Path
import pandas as pd

from utils.env import load_dotenv, get_env
from utils.parse_easymag import read_easymag_export_first_table, classify_export, normalize_export
from utils.gate_map import read_gate_map

def find_latest_excels(inbox: Path) -> list[Path]:
    files = sorted(inbox.glob("*.xlsx"), key=lambda p: p.stat().st_mtime, reverse=True)
    return files

def main() -> None:
    load_dotenv()
    inbox = Path(get_env("DATA_INBOX", "./data/inbox")).resolve()
    lake = Path(get_env("DATA_LAKE", "./data/lake")).resolve()
    gate_map_path = Path(get_env("GATE_MAP", "./data/GATE.xlsx")).resolve()

    inbox.mkdir(parents=True, exist_ok=True)
    lake.mkdir(parents=True, exist_ok=True)

    gate_map = read_gate_map(gate_map_path)

    candidates = find_latest_excels(inbox)
    if not candidates:
        raise SystemExit(f"Nessun file .xlsx trovato in {inbox}")

    parsed = []
    for p in candidates[:10]:  # guarda ultimi 10
        try:
            df = read_easymag_export_first_table(p)
            kind = classify_export(df)
            if kind == "unknown":
                continue
            norm = normalize_export(df)
            if norm.empty:
                continue
            norm["kind"] = kind
            norm["source_file"] = p.name
            parsed.append(norm)
        except Exception:
            continue

    if not parsed:
        raise SystemExit("Non sono riuscito a riconoscere export 'righe' o 'colli'. Verifica i file in inbox.")

    all_norm = pd.concat(parsed, ignore_index=True)

    # separa righe/colli, scegli l'ultimo file per ciascun kind (in base a mtime)
    latest_by_kind = {}
    for kind in ["righe", "colli"]:
        dfk = all_norm[all_norm["kind"] == kind].copy()
        if dfk.empty:
            continue
        # ordina per source file mtime
        dfk["mtime"] = dfk["source_file"].map(lambda n: (inbox / n).stat().st_mtime if (inbox / n).exists() else 0)
        dfk = dfk.sort_values("mtime", ascending=False)
        latest_file = dfk.iloc[0]["source_file"]
        latest_by_kind[kind] = dfk[dfk["source_file"] == latest_file].drop(columns=["mtime"], errors="ignore")

    if "righe" not in latest_by_kind or "colli" not in latest_by_kind:
        raise SystemExit("Mi serve 1 file 'righe' e 1 file 'colli' in inbox (o riconoscibili).")

    righe = latest_by_kind["righe"].rename(columns={"Valore": "Righe"})
    colli = latest_by_kind["colli"].rename(columns={"Valore": "Colli"})

    # merge su Giro + Data (se Data mancante, merge solo su Giro)
    if righe["Data"].notna().any() and colli["Data"].notna().any():
        fact = pd.merge(righe[["Giro","Data","Righe"]], colli[["Giro","Data","Colli"]], on=["Giro","Data"], how="outer")
    else:
        fact = pd.merge(righe[["Giro","Righe"]], colli[["Giro","Colli"]], on=["Giro"], how="outer")
        fact["Data"] = pd.NaT

    fact = fact.merge(gate_map, on="Giro", how="left")
    fact["Gate"] = fact["Gate"].fillna("(Senza Gate)")
    fact["Righe"] = pd.to_numeric(fact.get("Righe"), errors="coerce").fillna(0)
    fact["Colli"] = pd.to_numeric(fact.get("Colli"), errors="coerce").fillna(0)

    # salva parquet
    out = lake / "fact_gate_workload.parquet"
    fact.to_parquet(out, index=False)

    meta = pd.DataFrame([{
        "updated_at": pd.Timestamp.now(tz=os.getenv("TZ","Europe/Rome")).isoformat(),
        "inbox": str(inbox),
        "righe_file": latest_by_kind["righe"]["source_file"].iloc[0],
        "colli_file": latest_by_kind["colli"]["source_file"].iloc[0],
        "rows": len(fact)
    }])
    meta.to_json(lake / "refresh_meta.json", orient="records", indent=2)
    print(f"OK: salvato {out} (rows={len(fact)})")

if __name__ == "__main__":
    main()
