
from __future__ import annotations
from pathlib import Path
import pandas as pd

def read_gate_map(gate_xlsx: str | Path) -> pd.DataFrame:
    """Legge GATE.xlsx. Atteso:
    - Colonna B: Giro
    - Colonna J: Gate
    """
    gate_xlsx = Path(gate_xlsx)
    df = pd.read_excel(gate_xlsx, engine="openpyxl")
    # supporta anche se colonne non hanno nome: fallback per indice
    cols = [c for c in df.columns]
    giro_col = None
    gate_col = None
    for c in cols:
        cl = str(c).strip().lower()
        if cl in ("giro", "giro consegna", "giro di consegna") or "giro" in cl:
            giro_col = c
        if cl in ("gate", "porta", "baia") or "gate" in cl:
            gate_col = c
    if giro_col is None and len(cols) >= 2:
        giro_col = cols[1]  # col B
    if gate_col is None and len(cols) >= 10:
        gate_col = cols[9]  # col J
    m = df[[giro_col, gate_col]].copy()
    m.columns = ["Giro", "Gate"]
    m["Giro"] = m["Giro"].astype(str).str.strip()
    m["Gate"] = m["Gate"].astype(str).str.strip()
    m = m.dropna()
    return m.drop_duplicates()
