
from __future__ import annotations
import re
from pathlib import Path
import pandas as pd

MARKER_RE = re.compile(r"\(\*\)\s*Numero\s+di\s+Operazioni", re.IGNORECASE)

def _find_marker_row(df_raw: pd.DataFrame) -> int | None:
    # search any cell for marker
    for i in range(len(df_raw)):
        row = df_raw.iloc[i].astype(str).tolist()
        if any(MARKER_RE.search(x or "") for x in row):
            return i
    return None

def read_easymag_export_first_table(xlsx_path: str | Path, sheet: str | int = 0) -> pd.DataFrame:
    """Legge l'export EasyMag e tronca alla riga marker '(*) Numero di Operazioni',
    prendendo SOLO la prima tabella (prima del raddoppio).
    """
    xlsx_path = Path(xlsx_path)
    df_raw = pd.read_excel(xlsx_path, sheet_name=sheet, header=None, engine="openpyxl")
    marker_row = _find_marker_row(df_raw)
    if marker_row is None:
        # fallback: proviamo a leggere normalmente con header=0
        return pd.read_excel(xlsx_path, sheet_name=sheet, engine="openpyxl")
    # la tabella è tipicamente sopra al marker; troviamo header come prima riga non vuota
    df_top = df_raw.iloc[:marker_row].copy()
    # drop righe completamente vuote
    df_top = df_top.dropna(how="all")
    if df_top.empty:
        return pd.DataFrame()
    # assume header is first remaining row
    header = df_top.iloc[0].astype(str).tolist()
    df = df_top.iloc[1:].copy()
    df.columns = header
    df = df.dropna(how="all")
    # rimuovi colonne "Unnamed"
    df = df.loc[:, [c for c in df.columns if not str(c).lower().startswith("unnamed")]]
    return df.reset_index(drop=True)

def classify_export(df: pd.DataFrame) -> str:
    """Ritorna 'righe' o 'colli' basandosi su colonne/etichette presenti."""
    cols = " ".join([str(c).lower() for c in df.columns])
    if "prelev" in cols or "righe" in cols or "linee" in cols:
        return "righe"
    if "colli" in cols or "packing" in cols:
        return "colli"
    # fallback: cerca in celle
    sample = df.head(20).astype(str).apply(lambda s: " ".join(s.tolist()), axis=1).str.lower().str.cat(sep=" ")
    if "prelev" in sample or "righe" in sample:
        return "righe"
    if "colli" in sample:
        return "colli"
    return "unknown"

def normalize_export(df: pd.DataFrame) -> pd.DataFrame:
    """Normalizza colonne per ottenere almeno:
    - Giro (delivery round)
    - Data (date)
    - Valore (numero operazioni/righe/colli)
    """
    if df.empty:
        return df
    # prova a individuare colonne
    colmap = {str(c).strip().lower(): c for c in df.columns}
    def pick(*cands):
        for c in cands:
            if c in colmap:
                return colmap[c]
        return None

    giro_col = pick("giro", "giro consegna", "giro di consegna", "tour", "route")
    date_col = pick("data", "data documento", "giorno", "date")
    val_col = pick("numero operazioni", "n. operazioni", "operazioni", "totale", "qta", "quantità", "quantita", "righe", "colli")

    # se val_col non trovato, prendi l'ultima colonna numerica
    if val_col is None:
        num_cols = [c for c in df.columns if pd.api.types.is_numeric_dtype(df[c])]
        val_col = num_cols[-1] if num_cols else df.columns[-1]

    out = pd.DataFrame()
    if giro_col is None:
        # fallback: se c'è colonna B tipica, prova la prima colonna
        giro_col = df.columns[0]
    out["Giro"] = df[giro_col].astype(str).str.strip()

    if date_col is not None:
        out["Data"] = pd.to_datetime(df[date_col], errors="coerce").dt.date
    else:
        out["Data"] = pd.NaT

    out["Valore"] = pd.to_numeric(df[val_col], errors="coerce")
    out = out.dropna(subset=["Giro", "Valore"])
    return out
